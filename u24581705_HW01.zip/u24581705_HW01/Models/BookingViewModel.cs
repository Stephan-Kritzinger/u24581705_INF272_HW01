﻿namespace u24581705_HW01.Models
{
    public class BookingViewModel
    {
        public string Service {  get; set; }
    }
}
