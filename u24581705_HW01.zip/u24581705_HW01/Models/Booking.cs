﻿namespace u24581705_HW01.Models
{
    public class Booking
    {
        public string GUID { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string Address { get; set; }
        public string Name { get; set; }
        public string dImage { get; set; }
        public string Number {  get; set; }
        public string Type { get; set; }
        public string vImage { get; set; }
        public string Registration { get; set; }
    }
}
